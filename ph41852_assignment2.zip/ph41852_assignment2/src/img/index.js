const LOGO = require('./coffe1.png')
module.exports ={
    LOGO
}
